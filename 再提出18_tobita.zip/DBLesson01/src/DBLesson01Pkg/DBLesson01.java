package DBLesson01Pkg;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DBLesson01 {
	public static void main(String[] args) {
		List<Word> array = new ArrayList<>();
		WordDAO wdao = new WordDAO();
		// コマンドラインから入力
		System.out.println("英単語と日本語をスペースで区切って入力して下さい。");
		Scanner sc  = new Scanner(System.in);
		String input = sc.nextLine();

		// 入力値登録
		try {
			while(!input.equals("e")) {
				String[] tmp = new String[2];
				tmp = input.split("　");
				Word wd = new Word(tmp[0], tmp[1]);
				array.add(wd);

				System.out.println("次の英単語と日本語を入力して下さい。\"e\"で終了します。");
				input = sc.nextLine();
			}

		} catch(Exception e) {
			e.printStackTrace();
		}
		int count = wdao.registWords(array);
		System.out.println(count + "件の登録が完了しました。");
	}
}

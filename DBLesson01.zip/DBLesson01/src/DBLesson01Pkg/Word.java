package DBLesson01Pkg;

public class Word{
	public String english;
	public String japanese;

	public Word(String _english, String _japanese) {
		this.english = _english;
		this.japanese = _japanese;
	}

	public String toString() {
		return "英単語：" + english + "　日本語：" + japanese;
	}

	public String getEnglish() {
		return english;
	}

	public void setEnglish(String _english) {
		this.english = _english;
	}

	public String getJapanese() {
		return japanese;
	}

	public void setJapanese(String _japanese) {
		this.japanese = _japanese;
	}
}
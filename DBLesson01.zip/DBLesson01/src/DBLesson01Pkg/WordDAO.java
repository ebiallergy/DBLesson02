package DBLesson01Pkg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class WordDAO {

	Connection con = null;
	PreparedStatement st = null;

	static String URL = "jdbc:mysql://localhost:8889/testdb";
	static String USER = "root";
	static String PW = "tamago";

	public int registWords(List<Word> words) {
		int result = 0;

		try {
			// DB接続の記述
			String SQL = "INSERT INTO dictionary(english, japanese, allText, other) VALUES (?, ?, ?, ?)";
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PW);

			// ここに日本語と英単語を登録する文
			for(Word tmp: words) {
				st = con.prepareStatement(SQL);
				st.setString(1,tmp.getEnglish());
				st.setString(2,tmp.getJapanese());
				st.setString(3,tmp.getEnglish() + "_" + tmp.getJapanese());
				st.setString(4,"-");
				st.executeUpdate();
				result++;
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if ( st != null) {
				try {
					st.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if ( con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;	// 結果を返す
	}

}

package DBLesson01Pkg;

import java.util.Scanner;
import DBLesson01Pkg.Word;
import java.util.ArrayList;
import java.util.List;

public class DBLesson01 {
	public static void main(String[] args) {
		List<Word> array = new ArrayList<>();
		WordDAO dao = new WordDAO();
		// コマンドラインから入力
		System.out.println("英単語と日本語をスペースで区切って入力して下さい。");
		Scanner sc  = new Scanner(System.in);
		String input = sc.nextLine();
		
		// ここから記述してください
		int index = 0;
		
		try {
			while(!input.equals("e")) {
				String[] tmp = new String[2];
				tmp = input.split("　");
				Word wd = new Word(tmp[0], tmp[1]);
				array.add(wd);
				dao.registWords(wd);
				
				index++;
				
				System.out.println("次の英単語と日本語を入力して下さい。\"e\"で終了します。");
				input = sc.nextLine();
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		for(int i=0; i<array.size(); i++) {
			array.get(i).say();
		}
		System.out.println(array.size() + "件、登録しました。");
	}
}

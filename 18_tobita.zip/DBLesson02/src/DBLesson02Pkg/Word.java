package DBLesson02Pkg;

public class Word{
	public String english;
	public String japanese;
	public String allText;
	public String oter;
	
	public Word(String _english, String _japanese) {
		this.english = _english;
		this.japanese = _japanese;
	}
	
	public String getEnglish() {
		return english;
	}
	
	public void setEnglish(String _english) {
		this.english = _english; 
	}
	
	public String getJapanese() {
		return japanese;
	}
	
	public void setJapanese(String _japanese) {
		this.japanese = _japanese; 
	}
	
	public void say() {
		System.out.println("英単語：" + this.english + "　日本語：" + this.japanese);
	}
}
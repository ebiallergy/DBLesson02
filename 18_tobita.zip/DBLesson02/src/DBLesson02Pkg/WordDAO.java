package DBLesson02Pkg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;

public class WordDAO {

	Connection con = null;
	PreparedStatement st = null;

	public int registWords(Word _array) {
		int result = 0;
		String eng = _array.english;
		String jpn = _array.japanese;
		
		try {
			// DB接続の記述
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:8889/testdb", "root", "tamago");
			
			if(con != null) {
				System.out.println("DB接続完了(getConnection後)\r\n----");
			} else {
				System.out.println("DB接続失敗\r\n----");
			}
			
			// ここに日本語と英単語を登録する文
			String SQL = "INSERT INTO dictionary(english, japanese, allText, other) VALUES (?, ?, ?, ?)";
			st = con.prepareStatement(SQL);
			st.setString(1,eng);
			st.setString(2,jpn);
			st.setString(3,eng + "_" + jpn);
			st.setString(4,"-");
			int count = st.executeUpdate();
			
		} catch (ClassNotFoundException e) {
			System.out.println("kokomade");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("ore");
			e.printStackTrace();
		} finally {
			if ( st != null) {
				try {
					st.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if ( con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;	// 結果を返す
	}
	public List<Word> getWords() {
		List<Word> words = new ArrayList<>();
		
		try {
			// DB接続の記述
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:8889/testdb", "root", "tamago");
			
			String SQL = "SELECT * FROM dictionary";
			st = con.prepareStatement(SQL);
			ResultSet rs = st.executeQuery();
			
			while (rs.next()) {
				Word text = new Word(rs.getString("english"), rs.getString("japanese"));
				words.add(text);
				}
			
		} catch (ClassNotFoundException e) {
			System.out.println("kokomade");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("ore");
			e.printStackTrace();
		} finally {
			if ( st != null) {
				try {
					st.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if ( con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return words;	// 結果を返す
	}

}
